package br.com.ascensaodosoberano

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import kotlin.random.Random

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  runCatching { FirebaseApp.initializeApp(this) }
  setContent { MaterialTheme { GameApp() } }
 }
}

data class Hero(
 val name:String="Entidade da Ascensão Cósmica", val level:Int=14, val xp:Int=825,
 val xpNext:Int=1000, val hp:Int=485, val hpMax:Int=485, val mana:Int=230,
 val manaMax:Int=330, val rank:String="Não consolidado",
 val classe:String="Soberano da Evolução (bloqueada)", val title:String="Matador de Calamidades"
)
data class Power(val name:String,val cost:String,val detail:String)

@Composable fun GameApp() {
 var page by remember { mutableStateOf(0) }
 var message by remember { mutableStateOf("Protótipo local. Configure Firebase para habilitar campanhas online.") }
 var invite by remember { mutableStateOf("") }
 var code by remember { mutableStateOf("") }
 val hero = remember { Hero() }
 val powers = remember { listOf(
  Power("Punhos da Calamidade Cósmica","0 Mana","Dano físico-base ainda não consolidado. Chamas integradas: 450 inicial + 90 por acúmulo/turno; até 6 acúmulos por 6 turnos."),
  Power("Eclipse do Soberano Abissal","100 Mana","2.250 de dano-base por alvo; alcance/raio 150 m; recarga 5 turnos."),
  Power("Manipulação Gravitacional","A confirmar","Puxar, conter, interromper ou comprimir; custo e recarga não consolidados."),
  Power("Domínio da Calamidade","A confirmar","Controle de área e bloqueio dimensional; parâmetros não consolidados.")
 ) }
 Scaffold(topBar={TopAppBarCompat("Ascensão do Soberano")},
  bottomBar={NavigationBar {
   listOf("Personagem","Combate","Multiplayer","Mundo").forEachIndexed { i,t ->
    NavigationBarItem(selected=page==i,onClick={page=i},icon={},label={Text(t)})
   }
  }}) { pad ->
  Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
   when(page) {
    0 -> LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
     item { Text(hero.name, style=MaterialTheme.typography.titleLarge) }
     item { Text("Nível ${hero.level} • XP ${hero.xp}/${hero.xpNext} • Rank ${hero.rank}") }
     item { LinearProgressIndicator(progress={hero.xp.toFloat()/hero.xpNext}, modifier=Modifier.fillMaxWidth()) }
     item { Text("HP ${hero.hp}/${hero.hpMax}  |  Mana ${hero.mana}/${hero.manaMax}") }
     item { Text("Classe: ${hero.classe}") }; item { Text("Título: ${hero.title}") }
     item { Text("Equipados: Couraça do Titã Imortal (SSS), Anel da Singularidade (SS)") }
     item { Text("Guardado: Escudo das Sete Virtudes (S)") }
     item { Text("Matriz Primordial: Integração Parcial; terceira camada selada.") }
    }
    1 -> LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
     item { Text("Combate e poderes", style=MaterialTheme.typography.titleLarge) }
     items(powers.size) { i -> Card { Column(Modifier.padding(12.dp)) {
      Text(powers[i].name,style=MaterialTheme.typography.titleMedium)
      Text("Custo: ${powers[i].cost}"); Text(powers[i].detail)
     } } }
     item { Button(onClick={message="D20: ${Random.nextInt(1,21)}. Defina CD e modificadores antes de resolver."}) { Text("Rolar D20") } }
    }
    2 -> Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
     Text("Campanhas individuais + convites",style=MaterialTheme.typography.titleLarge)
     Text("Cada jogador preserva sua campanha. Amigos podem entrar em sessões cooperativas convidadas.")
     Button(onClick={
      CoroutineScope(Dispatchers.Main).launch {
       try {
        val auth=FirebaseAuth.getInstance()
        val user=auth.currentUser ?: auth.signInAnonymously().await().user
        val db=FirebaseFirestore.getInstance()
        if(user==null) error("Autenticação não retornou usuário")
        val id=db.collection("campaigns").document().id
        val codeGen=(1..6).map { ('A'..'Z').random() }.joinToString("")
        db.collection("campaigns").document(id).set(mapOf("ownerUid" to user.uid,"inviteCode" to codeGen,"name" to "Campanha de ${hero.name}","visibility" to "private","members" to listOf(user.uid),"createdAt" to System.currentTimeMillis())).await()
        invite=codeGen; message="Campanha criada. Compartilhe o código $codeGen."
       } catch(e:Exception) { message="Online indisponível: ${e.localizedMessage}" }
      }
     }, modifier=Modifier.fillMaxWidth()) { Text("Criar campanha e gerar convite") }
     if(invite.isNotBlank()) Text("Convite: $invite",style=MaterialTheme.typography.headlineMedium)
     OutlinedTextField(value=code,onValueChange={code=it},label={Text("Código do amigo")},modifier=Modifier.fillMaxWidth())
     Button(onClick={
      CoroutineScope(Dispatchers.Main).launch {
       try {
        val auth=FirebaseAuth.getInstance()
        val user=auth.currentUser ?: auth.signInAnonymously().await().user
        val db=FirebaseFirestore.getInstance()
        if(user==null) error("Autenticação falhou")
        val q=db.collection("campaigns").whereEqualTo("inviteCode",code.trim().uppercase()).limit(1).get().await()
        val doc=q.documents.firstOrNull() ?: error("Código não encontrado")
        doc.reference.update("members",com.google.firebase.firestore.FieldValue.arrayUnion(user.uid)).await()
        message="Entrada confirmada na campanha ${doc.getString("name")}."
       } catch(e:Exception) { message="Não foi possível entrar: ${e.localizedMessage}" }
      }
     },modifier=Modifier.fillMaxWidth()) { Text("Entrar na campanha") }
    }
    else -> Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
     Text("Mundo aberto",style=MaterialTheme.typography.titleLarge)
     Text("Estrutura prevista: regiões persistentes, exploração, encontros, guildas, chefes mundiais e eventos.")
     Text("Sessões: campanha individual + instância cooperativa por convite.")
     Text("A economia, XP, itens, combate e recompensas deverão ser validados pelo servidor.")
    }
   }
   Spacer(Modifier.height(4.dp)); Text(message,style=MaterialTheme.typography.bodySmall)
  }
 }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TopAppBarCompat(title:String) { TopAppBar(title={Text(title)}) }
